module XTF
end
require 'rubygems'

require 'active_support'

$:.unshift(File.dirname(__FILE__))
require 'xtf/element'
require 'xtf/xml'