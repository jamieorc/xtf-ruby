class XTF::Element::Range < XTF::Element::Base
  
  def initialize(*args)
    @tag_name = "range"
    super
  end
  
end
