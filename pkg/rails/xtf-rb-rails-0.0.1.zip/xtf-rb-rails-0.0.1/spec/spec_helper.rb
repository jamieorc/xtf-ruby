require 'rubygems'
gem 'rspec'
require File.expand_path(File.dirname(__FILE__) + '/../lib/xtf')
require 'spec'